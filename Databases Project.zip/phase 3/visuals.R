attach(education)

BID <- Board.Number
bName <- Board.Name 
bLanguage <- Board.Language
bType <- Board.Type 

eResults <- Grade.6.EQAO.Reading.Results 
eProgress <- Progress.in.Grade.6.EQAO.Reading.Results

oResults <- Grade.10.OSSLT.Results
oProgress <- Progress.in.Grade.10.OSSLT.Results 

credit <- Credit.Accumulation.by.the.end.of.Grade.11 
progress <- Progress.in.Credit.Accumulation.by.the.end.of.Grade.11 

fourRate <- Four.Year.Graduation.Rate 
fourProgress <- Progress.in.Four.Year.Graduation.Rate 
fiveRate <- Five.Year.Graduation.Rate 
fiveProgress <- Progress.in.Five.Year.Graduation.Rate 

library(ggplot2)



